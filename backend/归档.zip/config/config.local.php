<?php
/**
 * 本地密钥（已 gitignore，勿提交）。
 * 你在对话里贴过明文 Key，建议尽快在控制台轮换。
 */
return array(
    'llm_enabled' => true,
    'llm_default_provider' => 'deepseek',

    'llm_providers' => array(
        'deepseek' => array(
            'name' => 'DeepSeek',
            'enabled' => true,
            'api_key' => getenv('DEEPSEEK_API_KEY') ?: 'sk-86c5cbccbd3d4ca4b5ad8c925a4428d9',
            'base_url' => getenv('DEEPSEEK_BASE_URL') ?: 'https://api.deepseek.com',
            'model' => getenv('DEEPSEEK_MODEL') ?: 'deepseek-chat',
        ),
        'qwen' => array(
            'name' => '通义千问',
            'enabled' => true,
            'api_key' => getenv('QWEN_VL_API_KEY')
                ?: 'sk-ws-H.EEIHPDR.IzaF.MEYCIQDSrq2WGCGPe0vvFuSE7FvlIpuX3O_KV53xpdIgYaoy5wIhAKU3b6GsR-GztAKi_AitY_4e505VOVMMGneBnbvN8CkN',
            'api_host' => getenv('QWEN_VL_API_HOST')
                ?: 'llm-4wub595drj9z6vpr.cn-beijing.maas.aliyuncs.com',
            'base_url' => getenv('QWEN_VL_BASE_URL')
                ?: 'https://llm-4wub595drj9z6vpr.cn-beijing.maas.aliyuncs.com/compatible-mode/v1',
            'model' => getenv('QWEN_VL_MODEL') ?: 'qwen-plus',
        ),
    ),
);
